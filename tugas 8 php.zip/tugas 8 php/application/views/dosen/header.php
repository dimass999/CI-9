<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>SAS-STTNF</title>
</head>
<body>

<header role="banner">
<h2>Student Activity Score - STTNF</h2>
<a href="#">Home</a> | <a href="#">Activity</a> | <a href="#">My Score</a>
<a href="#">Login</a>
<hr/>
</header>
